<?php
// Prevent multiple inclusions
if (!defined('ITALY_OPTICS_CONFIG')) {
    define('ITALY_OPTICS_CONFIG', true);

    // Error reporting during development
    error_reporting(E_ALL);
    ini_set('display_errors', '0'); // Clean HTML output, errors logged

    // Session initialization with project-local session path
    $sessionDir = __DIR__ . '/../sessions';
    if (!is_dir($sessionDir)) {
        @mkdir($sessionDir, 0777, true);
    }
    if (is_writable($sessionDir)) {
        @session_save_path($sessionDir);
    }
    if (session_status() === PHP_SESSION_NONE) {
        @session_start();
    }

    // Database Configuration
    define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
    define('DB_PORT', getenv('DB_PORT') ?: '3306');
    define('DB_NAME', getenv('DB_NAME') ?: 'italy_optics');
    define('DB_USER', getenv('DB_USER') ?: 'root');
    define('DB_PASS', getenv('DB_PASS') ?: '');
    define('DB_CHARSET', 'utf8mb4');

    // Store Details in Clean English
    define('SITE_NAME', 'Italy Optics');
    define('SITE_NAME_TITLE', 'Italy Optics | Premium Eyewear & Optician in Chittagong');
    define('SITE_TAGLINE', 'Optician in Chittagong · Luxury Monochrome Eyewear Studio');
    define('STORE_ADDRESS', '12 Jamal Khan Road, Chattogram 4000');
    define('STORE_ADDRESS_EN', '12 Jamal Khan Road, Chittagong 4000, Bangladesh');
    define('STORE_PHONE', '01708-541674');
    define('STORE_EMAIL', 'info@italyoptics.bd');
    define('STORE_HOURS', 'Open · Closes 10 PM');
    define('STORE_RATING', '5.0');
    define('STORE_REVIEWS_COUNT', '3 Google reviews');
    define('FACEBOOK_URL', 'https://facebook.com/italyoptics.ctg');
    define('CURRENCY', '৳');

    // SEO Meta Keywords & Description
    define('SITE_KEYWORDS', 'italy optics, optics chittagong, optician in chittagong, jamal khan optical shop, eyewear chattogram, eyeglasses chittagong, prescription glasses bangladesh, polarized sunglasses chittagong, blue light blocking glasses, computer glasses, contact lenses chittagong, eye testing jamal khan, luxury italian eyewear, titanium frames bd, designer sunglasses chattogram, reading glasses bangladesh');
    define('SITE_DESCRIPTION', 'Italy Optics is a 5.0-star rated optician in 12 Jamal Khan Road, Chattogram 4000. Discover handcrafted Italian acetate frames, ultra-light aerospace titanium eyeglasses, polarized UV400 sunglasses, and computerized prescription lenses.');

    // Base URL calculation
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '');
    $basePath = rtrim(str_replace(['/admin', '/api'], '', $scriptDir), '/\\');
    define('BASE_URL', $protocol . $host . $basePath);
}
